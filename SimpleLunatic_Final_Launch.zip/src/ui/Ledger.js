javascript
import React, { useEffect, useRef } from 'react';
import { View, Text, ScrollView, StyleSheet, Image } from 'react-native';
import { getCurrentRhythm } from '../logic/house-rhythms';

// Asset Link: Static require for moon phases
const MOON_PHASES = {
  'new': require('../../assets/moons/new.png'),
  'waxing_crescent': require('../../assets/moons/waxing_crescent.png'),
  'first_quarter': require('../../assets/moons/first_quarter.png'),
  'waxing_gibbous': require('../../assets/moons/waxing_gibbous.png'),
  'full': require('../../assets/moons/full.png'),
  // Add remaining phases as needed, defaulting to full for safety
};

export default function Ledger({ seeds, onPlant }) {
  const scrollRef = useRef(null);
  
  // Rhythmic Pacing Logic
  useEffect(() => {
    let animationFrameId;
    let velocity = 0;
    let scrollY = 0;

    const updateScrollPhysics = () => {
      // Fetch the current rhythmic modulation
      const rhythmFactor = getCurrentRhythm().tempoModulator;

      // Apply the rhythm to the friction
      // This creates the "Simple Lunatic" feel where scrolling tightens/loosens on the beat
      const friction = 0.95 * rhythmFactor;

      velocity *= friction;
      scrollY += velocity;

      // In a real scenario, we would apply 'scrollY' to the ScrollView here
      // For now, we log the modulation to verify the connection
      // console.log(`Rhythm Factor: ${rhythmFactor}, Velocity: ${velocity}`);

      animationFrameId = requestAnimationFrame(updateScrollPhysics);
    };

    updateScrollPhysics();

    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  return (
    <ScrollView 
      ref={scrollRef}
      style={styles.ledgerContainer}
      contentContainerStyle={styles.content}
    >
      {seeds.map((seed) => (
        <View key={seed.codex_id} style={styles.seedEntry}>
          <Image 
            source={MOON_PHASES[seed.phase] || MOON_PHASES['full']} 
            style={styles.moonIcon} 
          />
          <Text style={styles.seedText}>{seed.text}</Text>
          <Text style={styles.seedMeta}>{seed.codex_id} | {seed.frequency}Hz</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  ledgerContainer: { flex: 1, width: '100%' },
  content: { padding: 20 },
  seedEntry: { marginBottom: 20, padding: 15, backgroundColor: '#1a1a1a', borderRadius: 8 },
  moonIcon: { width: 30, height: 30, marginBottom: 10 },
  seedText: { color: '#fff', fontSize: 16 },
  seedMeta: { color: '#888', fontSize: 10, marginTop: 5 }
});