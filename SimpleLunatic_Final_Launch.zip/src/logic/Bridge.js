import { generateQuantumelodicComposition } from '../core/index.js';
import { playPulse } from './PulseEngine.js';

/**
 * Simple Lunatic Bridge
 * Connects User Intentions to the Astro-Sonic Engine
 */
export const plantIntentionalSeed = async (intention, chartData) => {
  // 1. Analyze the current sky via the Engine in /src/core
  const result = await generateQuantumelodicComposition(chartData, { duration: 3 });
  
  // 2. Trigger the 3-second 'frequency seed' (e.g., Moon at 210Hz)
  playPulse(result.metadata.chart.dominantPlanet);
  
  // 3. Return the data for the Ledger/Codex
  return {
    text: intention,
    codex: result.metadata.generatedAt,
    freq: result.metadata.audio.frequency,
    timestamp: new Date()
  };
};
