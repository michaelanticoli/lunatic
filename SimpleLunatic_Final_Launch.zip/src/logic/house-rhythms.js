export function getCurrentRhythm() {
  // Returns a modulator based on a simulated house beat (120 BPM approx)
  const time = Date.now() / 1000;
  const beat = Math.sin(time * Math.PI * 2); // Simple oscillation
  return { tempoModulator: 1 + (beat * 0.1) }; // Oscillates between 0.9 and 1.1
}