const PLANET_FREQUENCIES = {
  sun: 216, moon: 210, mercury: 288, venus: 432, 
  mars: 324, jupiter: 384, saturn: 256, pluto: 280
};

export const playPulse = (planet) => {
  const freq = PLANET_FREQUENCIES[planet] || 210;
  console.log("Playing frequency pulse: " + freq + " Hz");
};
