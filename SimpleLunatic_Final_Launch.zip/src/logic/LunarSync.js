export const calculateEchoes = (plantDate) => {
  return {
    nodal: new Date(plantDate).setMonth(plantDate.getMonth() + 18),
    flip: new Date(plantDate).setFullYear(plantDate.getFullYear() + 9),
    metonic: new Date(plantDate).setFullYear(plantDate.getFullYear() + 19)
  };
};
