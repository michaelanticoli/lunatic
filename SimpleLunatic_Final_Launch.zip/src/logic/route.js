export function generateCodexId() {
  // Generates a unique ID compatible with the backend route logic
  // biome-ignore lint/style/useTemplate: dynamic string concatenation is intentional
    return 'cdx_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now().toString(36);
}