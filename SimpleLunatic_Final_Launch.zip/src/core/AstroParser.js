/**
 * AstroParser - Swiss Ephemeris Data Parser
 * Processes natal chart JSON and extracts astrological data for musical translation
 */

import { getPlanetaryMode, applyZodiacModification } from '../mappings/planetary-modes.js';
import { calculateAspect, getAllAspects } from '../mappings/aspect-harmonics.js';
import { getHouseConfig, generateHouseRhythmSequence } from '../mappings/house-rhythms.js';

/**
 * Main parser class for astrological data
 */
export class AstroParser {
  constructor(ephemerisData) {
    this.rawData = ephemerisData;
    this.planets = {};
    this.houses = {};
    this.aspects = [];
    this.angles = {};
    
    this.validate();
    this.parse();
  }

  /**
   * Validate incoming ephemeris data
   */
  validate() {
    if (!this.rawData) {
      throw new Error('No ephemeris data provided');
    }

    // Expected structure from Swiss Ephemeris
    const requiredFields = ['planets', 'houses', 'angles'];
    
    for (const field of requiredFields) {
      if (!this.rawData[field]) {
        console.warn(`Missing field: ${field}. Using defaults.`);
      }
    }
  }

  /**
   * Parse ephemeris data into usable format
   */
  parse() {
    this.parsePlanets();
    this.parseHouses();
    this.parseAngles();
    this.calculateAspects();
  }

  /**
   * Parse planetary positions
   */
  parsePlanets() {
    const planetData = this.rawData.planets || {};
    
    const planetNames = [
      'Sun', 'Moon', 'Mercury', 'Venus', 'Mars',
      'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'
    ];

    for (const planetName of planetNames) {
      if (planetData[planetName]) {
        const data = planetData[planetName];
        
        this.planets[planetName] = {
          name: planetName,
          longitude: data.longitude || 0,
          latitude: data.latitude || 0,
          speed: data.speed || 0,
          sign: this.getZodiacSign(data.longitude || 0),
          degree: this.getSignDegree(data.longitude || 0),
          house: data.house || 1,
          retrograde: data.speed < 0,
          mode: getPlanetaryMode(planetName)
        };

        // Apply zodiac sign modification to mode
        this.planets[planetName].modifiedMode = applyZodiacModification(
          this.planets[planetName].mode,
          this.planets[planetName].sign
        );
      }
    }
  }

  /**
   * Parse house cusps
   */
  parseHouses() {
    const houseData = this.rawData.houses || {};
    
    for (let i = 1; i <= 12; i++) {
      const houseKey = `house${i}`;
      
      this.houses[i] = {
        number: i,
        cusp: houseData[houseKey] || (i - 1) * 30, // Default to equal house
        sign: this.getZodiacSign(houseData[houseKey] || (i - 1) * 30),
        config: getHouseConfig(i),
        planets: [] // Will be filled in assignPlanetsToHouses()
      };
    }

    this.assignPlanetsToHouses();
  }

  /**
   * Parse chart angles (ASC, MC, DSC, IC)
   */
  parseAngles() {
    const anglesData = this.rawData.angles || {};
    
    this.angles = {
      ascendant: anglesData.ascendant || this.houses[1]?.cusp || 0,
      midheaven: anglesData.midheaven || this.houses[10]?.cusp || 270,
      descendant: anglesData.descendant || this.houses[7]?.cusp || 180,
      ic: anglesData.ic || this.houses[4]?.cusp || 90
    };
  }

  /**
   * Calculate all planetary aspects
   */
  calculateAspects() {
    const planetPositions = {};
    
    for (const [name, data] of Object.entries(this.planets)) {
      planetPositions[name] = data.longitude;
    }

    this.aspects = getAllAspects(planetPositions);
  }

  /**
   * Assign planets to their respective houses
   */
  assignPlanetsToHouses() {
    for (const [planetName, planetData] of Object.entries(this.planets)) {
      const house = this.findHouseForPlanet(planetData.longitude);
      planetData.house = house;
      
      if (this.houses[house]) {
        this.houses[house].planets.push(planetName);
      }
    }
  }

  /**
   * Find which house a planet is in based on longitude
   */
  findHouseForPlanet(longitude) {
    for (let i = 1; i <= 12; i++) {
      const currentCusp = this.houses[i].cusp;
      const nextHouse = i === 12 ? 1 : i + 1;
      const nextCusp = this.houses[nextHouse].cusp;

      let inHouse = false;
      
      if (nextCusp > currentCusp) {
        // Normal case
        inHouse = longitude >= currentCusp && longitude < nextCusp;
      } else {
        // Wraps around 360°
        inHouse = longitude >= currentCusp || longitude < nextCusp;
      }

      if (inHouse) return i;
    }
    
    return 1; // Default to first house
  }

  /**
   * Get zodiac sign from longitude
   */
  getZodiacSign(longitude) {
    const signs = [
      'Aries', 'Taurus', 'Gemini', 'Cancer', 
      'Leo', 'Virgo', 'Libra', 'Scorpio',
      'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'
    ];
    
    const normalizedLongitude = ((longitude % 360) + 360) % 360;
    const signIndex = Math.floor(normalizedLongitude / 30);
    
    return signs[signIndex];
  }

  /**
   * Get degree within zodiac sign
   */
  getSignDegree(longitude) {
    const normalizedLongitude = ((longitude % 360) + 360) % 360;
    return normalizedLongitude % 30;
  }

  /**
   * Get houses with planets (for rhythm generation)
   */
  getHousePlacements() {
    const placements = [];
    
    for (const [houseNum, houseData] of Object.entries(this.houses)) {
      if (houseData.planets && houseData.planets.length > 0) {
        for (const planet of houseData.planets) {
          placements.push({
            house: parseInt(houseNum),
            planet: planet
          });
        }
      }
    }
    
    return placements;
  }

  /**
   * Calculate overall chart tempo based on planetary speeds
   */
  calculateChartTempo(baseTempo = 120) {
    const speeds = Object.values(this.planets).map(p => Math.abs(p.speed));
    const avgSpeed = speeds.reduce((a, b) => a + b, 0) / speeds.length;
    
    // Normalize average speed (typical range: 0-15 deg/day)
    const speedFactor = avgSpeed / 1.0; // Moon's average speed as baseline
    
    // Modulate tempo: faster planets = faster tempo
    const tempoModifier = (speedFactor - 1) * 30;
    const finalTempo = Math.max(60, Math.min(180, baseTempo + tempoModifier));
    
    return Math.round(finalTempo);
  }

  /**
   * Get chart summary for musical generation
   */
  getMusicalSummary() {
    return {
      planets: this.planets,
      houses: this.houses,
      aspects: this.aspects,
      angles: this.angles,
      tempo: this.calculateChartTempo(),
      housePlacements: this.getHousePlacements(),
      dominantElement: this.getDominantElement(),
      chartPattern: this.identifyChartPattern()
    };
  }

  /**
   * Identify dominant element in chart
   */
  getDominantElement() {
    const elements = { fire: 0, earth: 0, air: 0, water: 0 };
    
    const elementMap = {
      Aries: 'fire', Leo: 'fire', Sagittarius: 'fire',
      Taurus: 'earth', Virgo: 'earth', Capricorn: 'earth',
      Gemini: 'air', Libra: 'air', Aquarius: 'air',
      Cancer: 'water', Scorpio: 'water', Pisces: 'water'
    };

    for (const planet of Object.values(this.planets)) {
      const element = elementMap[planet.sign];
      if (element) elements[element]++;
    }

    return Object.entries(elements).sort((a, b) => b[1] - a[1])[0][0];
  }

  /**
   * Identify major chart pattern
   */
  identifyChartPattern() {
    // Simplified pattern identification
    const patterns = {
      stellium: false,
      grandTrine: false,
      grandCross: false,
      yod: false,
      kite: false
    };

    // Check for stellium (3+ planets in same sign)
    const signCounts = {};
    for (const planet of Object.values(this.planets)) {
      signCounts[planet.sign] = (signCounts[planet.sign] || 0) + 1;
    }
    patterns.stellium = Object.values(signCounts).some(count => count >= 3);

    // Check for grand trine (3 trines forming triangle)
    const trines = this.aspects.filter(a => a.type === 'trine');
    patterns.grandTrine = trines.length >= 3;

    // Check for grand cross (4 squares + 2 oppositions)
    const squares = this.aspects.filter(a => a.type === 'square');
    const oppositions = this.aspects.filter(a => a.type === 'opposition');
    patterns.grandCross = squares.length >= 4 && oppositions.length >= 2;

    return patterns;
  }
}

/**
 * Helper function to create parser from Swiss Ephemeris JSON
 * @param {Object|string} data - Ephemeris data object or JSON string
 * @returns {AstroParser} Parser instance
 */
export function createParser(data) {
  let parsedData = data;
  
  if (typeof data === 'string') {
    try {
      parsedData = JSON.parse(data);
    } catch (error) {
      throw new Error('Invalid JSON data: ' + error.message);
    }
  }
  
  return new AstroParser(parsedData);
}

export default AstroParser;
