/**
 * CompositionEngine - Musical Structure Assembly
 * Converts astrological data into structured musical composition
 */

import { aspectToChord, calculateHarmonicTension } from '../mappings/aspect-harmonics.js';
import { generateHouseRhythmSequence, calculateHouseTempo } from '../mappings/house-rhythms.js';
import { noteToFrequency } from '../mappings/planetary-modes.js';

/**
 * Main composition engine class
 */
export class CompositionEngine {
  constructor(musicalSummary, options = {}) {
    this.summary = musicalSummary;
    this.options = {
      duration: options.duration || 180, // 3 minutes default
      complexity: options.complexity || 0.5,
      harmonic: options.harmonic || true,
      melodic: options.melodic || true,
      ...options
    };

    this.composition = {
      metadata: {},
      structure: [],
      melodies: [],
      harmonies: [],
      rhythms: [],
      tempo: this.summary.tempo,
      timeSignature: '4/4'
    };
  }

  /**
   * Generate complete composition
   */
  generate() {
    this.generateMetadata();
    this.generateStructure();
    this.generatePlanetaryMelodies();
    this.generateAspectHarmonies();
    this.generateHouseRhythms();
    
    return this.composition;
  }

  /**
   * Generate composition metadata
   */
  generateMetadata() {
    this.composition.metadata = {
      tempo: this.summary.tempo,
      keySignature: this.getPrimaryKey(),
      dominantElement: this.summary.dominantElement,
      chartPattern: this.summary.chartPattern,
      harmonicTension: calculateHarmonicTension(this.summary.aspects),
      totalPlanets: Object.keys(this.summary.planets).length,
      totalAspects: this.summary.aspects.length,
      generatedAt: new Date().toISOString()
    };
  }

  /**
   * Get primary key based on Sun sign
   */
  getPrimaryKey() {
    const sunPlanet = this.summary.planets.Sun;
    if (!sunPlanet) return 'C Major';
    
    return `${sunPlanet.modifiedMode.rootNote.replace(/\d+/, '')} ${sunPlanet.modifiedMode.mode}`;
  }

  /**
   * Generate overall composition structure
   */
  generateStructure() {
    const duration = this.options.duration;
    const tempo = this.composition.tempo;
    const beatsPerSecond = tempo / 60;
    const totalBeats = duration * beatsPerSecond;
    
    // Divide into sections based on house placements
    const sections = [];
    const housePlacements = this.summary.housePlacements;
    
    if (housePlacements.length === 0) {
      // Default structure if no house placements
      sections.push(
        { name: 'intro', start: 0, duration: 16, intensity: 0.3 },
        { name: 'verse', start: 16, duration: 32, intensity: 0.6 },
        { name: 'chorus', start: 48, duration: 24, intensity: 0.9 },
        { name: 'outro', start: 72, duration: 16, intensity: 0.4 }
      );
    } else {
      // Generate sections from house placements
      const beatsPerSection = totalBeats / housePlacements.length;
      let currentBeat = 0;
      
      for (const placement of housePlacements) {
        const houseConfig = this.summary.houses[placement.house].config;
        
        sections.push({
          name: houseConfig.structuralRole,
          house: placement.house,
          planet: placement.planet,
          start: currentBeat,
          duration: Math.max(16, beatsPerSection),
          intensity: houseConfig.beatStrength
        });
        
        currentBeat += beatsPerSection;
      }
    }
    
    this.composition.structure = sections;
  }

  /**
   * Generate melodic lines for each planet
   */
  generatePlanetaryMelodies() {
    const melodies = [];
    
    for (const [planetName, planetData] of Object.entries(this.summary.planets)) {
      const melody = this.generatePlanetMelody(planetName, planetData);
      melodies.push(melody);
    }
    
    this.composition.melodies = melodies;
  }

  /**
   * Generate melody for a specific planet
   */
  generatePlanetMelody(planetName, planetData) {
    const mode = planetData.modifiedMode;
    const scale = mode.scale;
    const rootNote = mode.rootNote;
    
    // Generate melodic pattern based on planetary position
    const notes = [];
    const beatsPerSection = 16; // Standard phrase length
    
    // Use planetary longitude to seed melody pattern
    const seed = planetData.longitude;
    const noteCount = 16;
    
    for (let i = 0; i < noteCount; i++) {
      // Generate pseudo-random but deterministic note selection
      const noteIndex = Math.floor((seed * (i + 1)) % scale.length);
      const octaveModifier = Math.floor((seed * (i + 1)) / 360) % 2;
      const note = scale[noteIndex];
      const octave = parseInt(rootNote.match(/\d+/)[0]) + octaveModifier;
      
      // Calculate timing
      const beat = (i / noteCount) * beatsPerSection;
      const duration = beatsPerSection / noteCount;
      
      // Velocity based on planet speed (faster = louder)
      const velocity = Math.min(1.0, 0.5 + (Math.abs(planetData.speed) / 2));
      
      notes.push({
        note: `${note}${octave}`,
        frequency: noteToFrequency(`${note}${octave}`),
        beat: beat,
        duration: duration,
        velocity: velocity
      });
    }
    
    return {
      planet: planetName,
      mode: mode.mode,
      rootNote: rootNote,
      waveform: mode.waveform,
      brightness: mode.brightness,
      notes: notes,
      retrograde: planetData.retrograde
    };
  }

  /**
   * Generate harmonic progressions from aspects
   */
  generateAspectHarmonies() {
    const harmonies = [];
    
    for (const aspect of this.summary.aspects) {
      const planet1 = this.summary.planets[aspect.planet1];
      const planet2 = this.summary.planets[aspect.planet2];
      
      if (!planet1 || !planet2) continue;
      
      // Create chord from aspect
      const rootNote = planet1.modifiedMode.rootNote;
      const chordNotes = aspectToChord(rootNote, aspect);
      
      harmonies.push({
        aspect: aspect.type,
        planet1: aspect.planet1,
        planet2: aspect.planet2,
        tension: aspect.tension,
        chordType: aspect.chordType,
        notes: chordNotes,
        frequencies: chordNotes.map(note => noteToFrequency(note)),
        duration: 4, // 4 beats per chord
        orb: aspect.orb
      });
    }
    
    // Sort by tension to create progression
    harmonies.sort((a, b) => a.tension - b.tension);
    
    this.composition.harmonies = harmonies;
  }

  /**
   * Generate rhythmic patterns from houses
   */
  generateHouseRhythms() {
    const rhythms = generateHouseRhythmSequence(this.summary.housePlacements);
    this.composition.rhythms = rhythms;
  }

  /**
   * Get composition timeline
   * Merges melodies, harmonies, and rhythms into a unified timeline
   */
  getTimeline() {
    const timeline = [];
    const tempo = this.composition.tempo;
    const beatDuration = 60 / tempo; // seconds per beat
    
    // Add structural markers
    for (const section of this.composition.structure) {
      timeline.push({
        type: 'section',
        time: section.start * beatDuration,
        data: section
      });
    }
    
    // Add melodic events
    for (const melody of this.composition.melodies) {
      for (const note of melody.notes) {
        timeline.push({
          type: 'melody',
          time: note.beat * beatDuration,
          duration: note.duration * beatDuration,
          data: {
            planet: melody.planet,
            ...note,
            waveform: melody.waveform,
            brightness: melody.brightness
          }
        });
      }
    }
    
    // Add harmonic events
    let harmonicTime = 0;
    for (const harmony of this.composition.harmonies) {
      timeline.push({
        type: 'harmony',
        time: harmonicTime,
        duration: harmony.duration * beatDuration,
        data: harmony
      });
      harmonicTime += harmony.duration * beatDuration;
    }
    
    // Add rhythmic events
    for (const rhythm of this.composition.rhythms) {
      for (let i = 0; i < rhythm.phraseLength; i++) {
        timeline.push({
          type: 'rhythm',
          time: (rhythm.startTime + i * 4) * beatDuration,
          data: {
            ...rhythm,
            beat: i + 1
          }
        });
      }
    }
    
    // Sort by time
    timeline.sort((a, b) => a.time - b.time);
    
    return timeline;
  }

  /**
   * Export composition data
   */
  export() {
    return {
      composition: this.composition,
      timeline: this.getTimeline(),
      summary: this.summary,
      options: this.options
    };
  }
}

/**
 * Helper function to create composition from musical summary
 */
export function createComposition(musicalSummary, options = {}) {
  const engine = new CompositionEngine(musicalSummary, options);
  return engine.generate();
}

export default CompositionEngine;
