/**
 * Quantumelodic Engine - Main Entry Point
 * Complete system for translating astrological data into music
 */

import { AstroParser, createParser } from './AstroParser.js';
import { CompositionEngine, createComposition } from './CompositionEngine.js';
import { AudioRenderer, renderAudio } from './AudioRenderer.js';
import { PLANETARY_MODES } from '../mappings/planetary-modes.js';
import { ASPECT_HARMONICS } from '../mappings/aspect-harmonics.js';
import { HOUSE_RHYTHMS } from '../mappings/house-rhythms.js';

/**
 * Generate a complete Quantumelodic composition from natal chart data
 * @param {Object} natalChartData - Swiss Ephemeris JSON data
 * @param {Object} options - Composition options
 * @returns {Promise<Object>} Generated audio and metadata
 */
export async function generateQuantumelodicComposition(natalChartData, options = {}) {
  try {
    // Step 1: Parse astrological data
    console.log('Parsing natal chart data...');
    const parser = createParser(natalChartData);
    const musicalSummary = parser.getMusicalSummary();
    
    // Step 2: Generate musical composition
    console.log('Generating musical composition...');
    const compositionEngine = new CompositionEngine(musicalSummary, options);
    const composition = compositionEngine.generate();
    const exportedComposition = compositionEngine.export();
    
    // Step 3: Render audio
    console.log('Rendering audio...');
    const audioResult = await renderAudio(exportedComposition, options);
    
    // Step 4: Prepare metadata
    const metadata = {
      chart: {
        planets: musicalSummary.planets,
        aspects: musicalSummary.aspects,
        houses: musicalSummary.houses,
        tempo: musicalSummary.tempo,
        dominantElement: musicalSummary.dominantElement
      },
      composition: {
        tempo: composition.tempo,
        keySignature: composition.metadata.keySignature,
        structure: composition.structure,
        totalMelodies: composition.melodies.length,
        totalHarmonies: composition.harmonies.length,
        totalRhythms: composition.rhythms.length
      },
      audio: {
        duration: audioResult.duration,
        sampleRate: audioResult.sampleRate,
        format: options.format || 'wav'
      },
      generatedAt: new Date().toISOString()
    };
    
    console.log('Composition complete!');
    
    return {
      audioBlob: audioResult.blob,
      audioBuffer: audioResult.audioBuffer,
      metadata: metadata,
      composition: exportedComposition,
      downloadUrl: URL.createObjectURL(audioResult.blob)
    };
    
  } catch (error) {
    console.error('Error generating composition:', error);
    throw new Error(`Quantumelodic generation failed: ${error.message}`);
  }
}

/**
 * Parse natal chart data only (without generating audio)
 * @param {Object} natalChartData - Swiss Ephemeris JSON data
 * @returns {Object} Parsed astrological and musical data
 */
export function parseNatalChart(natalChartData) {
  const parser = createParser(natalChartData);
  return parser.getMusicalSummary();
}

/**
 * Generate composition structure only (without rendering audio)
 * @param {Object} musicalSummary - Output from parseNatalChart
 * @param {Object} options - Composition options
 * @returns {Object} Musical composition structure
 */
export function generateComposition(musicalSummary, options = {}) {
  const engine = new CompositionEngine(musicalSummary, options);
  return engine.export();
}

/**
 * Render composition to audio
 * @param {Object} composition - Output from generateComposition
 * @param {Object} options - Rendering options
 * @returns {Promise<Object>} Audio blob and metadata
 */
export async function renderComposition(composition, options = {}) {
  return await renderAudio(composition, options);
}

/**
 * Get available mappings (for customization)
 */
export function getMappings() {
  return {
    planetaryModes: PLANETARY_MODES,
    aspectHarmonics: ASPECT_HARMONICS,
    houseRhythms: HOUSE_RHYTHMS
  };
}

/**
 * Create sample natal chart data for testing
 */
export function createSampleNatalChart() {
  return {
    planets: {
      Sun: { longitude: 45.5, latitude: 0, speed: 1.0, house: 1 },
      Moon: { longitude: 120.3, latitude: 5.1, speed: 13.2, house: 5 },
      Mercury: { longitude: 60.0, latitude: 2.1, speed: 1.5, house: 2 },
      Venus: { longitude: 30.7, latitude: 1.2, speed: 1.2, house: 1 },
      Mars: { longitude: 200.4, latitude: -1.5, speed: 0.6, house: 7 },
      Jupiter: { longitude: 150.8, latitude: 0.8, speed: 0.1, house: 6 },
      Saturn: { longitude: 270.2, latitude: 2.2, speed: 0.05, house: 10 },
      Uranus: { longitude: 90.5, latitude: 0.5, speed: 0.03, house: 4 },
      Neptune: { longitude: 330.1, latitude: -1.1, speed: 0.02, house: 12 },
      Pluto: { longitude: 250.6, latitude: 14.2, speed: 0.01, house: 9 }
    },
    houses: {
      house1: 0,
      house2: 30,
      house3: 60,
      house4: 90,
      house5: 120,
      house6: 150,
      house7: 180,
      house8: 210,
      house9: 240,
      house10: 270,
      house11: 300,
      house12: 330
    },
    angles: {
      ascendant: 0,
      midheaven: 270,
      descendant: 180,
      ic: 90
    }
  };
}

/**
 * Validate natal chart data structure
 * @param {Object} data - Natal chart data to validate
 * @returns {Object} Validation result with errors if any
 */
export function validateNatalChartData(data) {
  const errors = [];
  
  if (!data) {
    errors.push('No data provided');
    return { valid: false, errors };
  }
  
  // Check required fields
  if (!data.planets) {
    errors.push('Missing planets data');
  } else {
    const requiredPlanets = ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 
                             'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'];
    for (const planet of requiredPlanets) {
      if (!data.planets[planet]) {
        errors.push(`Missing planet: ${planet}`);
      } else {
        if (data.planets[planet].longitude === undefined) {
          errors.push(`Missing longitude for ${planet}`);
        }
      }
    }
  }
  
  if (!data.houses) {
    errors.push('Missing houses data');
  }
  
  return {
    valid: errors.length === 0,
    errors: errors
  };
}

// Export everything
export {
  AstroParser,
  CompositionEngine,
  AudioRenderer,
  createParser,
  createComposition,
  renderAudio,
  PLANETARY_MODES,
  ASPECT_HARMONICS,
  HOUSE_RHYTHMS
};

// Default export
export default {
  generateQuantumelodicComposition,
  parseNatalChart,
  generateComposition,
  renderComposition,
  getMappings,
  createSampleNatalChart,
  validateNatalChartData
};
