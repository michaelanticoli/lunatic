/**
 * AudioRenderer - Audio Synthesis Engine
 * Renders composition data into actual audio using Tone.js
 */

import * as Tone from 'tone';

/**
 * Main audio rendering class
 */
export class AudioRenderer {
  constructor(composition, options = {}) {
    this.composition = composition;
    this.timeline = composition.timeline || [];
    this.options = {
      format: options.format || 'wav',
      quality: options.quality || 'high',
      sampleRate: options.sampleRate || 44100,
      ...options
    };

    this.instruments = new Map();
    this.effects = new Map();
    this.isRendering = false;
  }

  /**
   * Initialize Tone.js and create instruments
   */
  async initialize() {
    await Tone.start();
    
    // Set tempo
    Tone.Transport.bpm.value = this.composition.composition.tempo;
    
    // Create instruments for each planet
    this.createInstruments();
    
    // Create effects chain
    this.createEffects();
  }

  /**
   * Create synthesizer instruments
   */
  createInstruments() {
    const waveformMap = {
      'sine': 'sine',
      'square': 'square',
      'sawtooth': 'sawtooth',
      'triangle': 'triangle',
      'custom': 'sine' // Default for custom
    };

    // Create an instrument for each planet's melody
    for (const melody of this.composition.composition.melodies) {
      const waveform = waveformMap[melody.waveform] || 'sine';
      
      // Create a polyphonic synthesizer
      const synth = new Tone.PolySynth(Tone.Synth, {
        oscillator: {
          type: waveform
        },
        envelope: {
          attack: 0.05,
          decay: 0.2,
          sustain: 0.5,
          release: 0.8
        },
        volume: -10 // Start quieter for better mixing
      }).toDestination();

      // Apply brightness filter
      const filter = new Tone.Filter({
        frequency: 1000 + (melody.brightness * 5000),
        type: 'lowpass',
        rolloff: -24
      });

      synth.connect(filter);
      filter.toDestination();

      this.instruments.set(melody.planet, { synth, filter });
    }

    // Create harmony instrument (pad-like)
    const harmonyPad = new Tone.PolySynth(Tone.Synth, {
      oscillator: {
        type: 'sine'
      },
      envelope: {
        attack: 1.0,
        decay: 0.5,
        sustain: 0.8,
        release: 2.0
      },
      volume: -15
    }).toDestination();

    this.instruments.set('harmony', { synth: harmonyPad });

    // Create rhythm instrument (percussive)
    const rhythmSynth = new Tone.MembraneSynth({
      pitchDecay: 0.05,
      octaves: 4,
      oscillator: {
        type: 'sine'
      },
      envelope: {
        attack: 0.001,
        decay: 0.4,
        sustain: 0.01,
        release: 0.4
      },
      volume: -8
    }).toDestination();

    this.instruments.set('rhythm', { synth: rhythmSynth });
  }

  /**
   * Create audio effects
   */
  createEffects() {
    // Reverb for ambiance
    const reverb = new Tone.Reverb({
      decay: 3,
      wet: 0.3
    }).toDestination();

    this.effects.set('reverb', reverb);

    // Delay for depth
    const delay = new Tone.FeedbackDelay({
      delayTime: '8n',
      feedback: 0.3,
      wet: 0.2
    }).toDestination();

    this.effects.set('delay', delay);
  }

  /**
   * Schedule all events on the timeline
   */
  scheduleEvents() {
    for (const event of this.timeline) {
      if (event.type === 'melody') {
        this.scheduleMelodyNote(event);
      } else if (event.type === 'harmony') {
        this.scheduleHarmony(event);
      } else if (event.type === 'rhythm') {
        this.scheduleRhythm(event);
      }
    }
  }

  /**
   * Schedule a melody note
   */
  scheduleMelodyNote(event) {
    const instrument = this.instruments.get(event.data.planet);
    if (!instrument) return;

    Tone.Transport.schedule((time) => {
      instrument.synth.triggerAttackRelease(
        event.data.note,
        event.duration,
        time,
        event.data.velocity
      );
    }, event.time);
  }

  /**
   * Schedule a harmony chord
   */
  scheduleHarmony(event) {
    const instrument = this.instruments.get('harmony');
    if (!instrument) return;

    Tone.Transport.schedule((time) => {
      instrument.synth.triggerAttackRelease(
        event.data.notes,
        event.duration,
        time,
        0.3
      );
    }, event.time);
  }

  /**
   * Schedule a rhythm hit
   */
  scheduleRhythm(event) {
    const instrument = this.instruments.get('rhythm');
    if (!instrument) return;

    if (!event.data.pattern || !event.data.pattern[event.data.beat - 1]) {
      return;
    }

    const freq = 100 + (event.data.house * 20); // Vary pitch by house

    Tone.Transport.schedule((time) => {
      instrument.synth.triggerAttackRelease(
        freq,
        '16n',
        time,
        event.data.beatStrength
      );
    }, event.time);
  }

  /**
   * Render audio to buffer
   */
  async render() {
    if (this.isRendering) {
      throw new Error('Already rendering');
    }

    this.isRendering = true;

    try {
      await this.initialize();
      
      // Calculate total duration
      const totalDuration = Math.max(
        ...this.timeline.map(e => e.time + (e.duration || 0))
      );

      // Create offline context for rendering
      const offline = new Tone.Offline((time) => {
        this.scheduleEvents();
        Tone.Transport.start(0);
      }, totalDuration + 2); // Add 2 seconds for reverb tail

      const buffer = await offline;
      
      this.isRendering = false;
      return buffer;
      
    } catch (error) {
      this.isRendering = false;
      throw error;
    }
  }

  /**
   * Convert Tone.js buffer to AudioBuffer
   */
  bufferToAudioBuffer(toneBuffer) {
    // Tone.js buffers are already AudioBuffers
    return toneBuffer.get();
  }

  /**
   * Export as WAV blob
   */
  async exportWAV(audioBuffer) {
    // Convert AudioBuffer to WAV
    const wav = await this.audioBufferToWav(audioBuffer);
    return new Blob([wav], { type: 'audio/wav' });
  }

  /**
   * Convert AudioBuffer to WAV format
   */
  async audioBufferToWav(audioBuffer) {
    const numberOfChannels = audioBuffer.numberOfChannels;
    const sampleRate = audioBuffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;

    let result;
    if (numberOfChannels === 2) {
      result = this.interleave(
        audioBuffer.getChannelData(0),
        audioBuffer.getChannelData(1)
      );
    } else {
      result = audioBuffer.getChannelData(0);
    }

    const buffer = new ArrayBuffer(44 + result.length * 2);
    const view = new DataView(buffer);

    // WAV header
    this.writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + result.length * 2, true);
    this.writeString(view, 8, 'WAVE');
    this.writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // fmt chunk size
    view.setUint16(20, format, true);
    view.setUint16(22, numberOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numberOfChannels * bitDepth / 8, true);
    view.setUint16(32, numberOfChannels * bitDepth / 8, true);
    view.setUint16(34, bitDepth, true);
    this.writeString(view, 36, 'data');
    view.setUint32(40, result.length * 2, true);

    // Write PCM data
    this.floatTo16BitPCM(view, 44, result);

    return buffer;
  }

  /**
   * Interleave left and right channels
   */
  interleave(leftChannel, rightChannel) {
    const length = leftChannel.length + rightChannel.length;
    const result = new Float32Array(length);

    let inputIndex = 0;
    for (let i = 0; i < length;) {
      result[i++] = leftChannel[inputIndex];
      result[i++] = rightChannel[inputIndex];
      inputIndex++;
    }
    return result;
  }

  /**
   * Write string to DataView
   */
  writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  /**
   * Convert float samples to 16-bit PCM
   */
  floatTo16BitPCM(view, offset, input) {
    for (let i = 0; i < input.length; i++, offset += 2) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
  }

  /**
   * Clean up resources
   */
  dispose() {
    for (const instrument of this.instruments.values()) {
      if (instrument.synth) {
        instrument.synth.dispose();
      }
      if (instrument.filter) {
        instrument.filter.dispose();
      }
    }

    for (const effect of this.effects.values()) {
      effect.dispose();
    }

    this.instruments.clear();
    this.effects.clear();
  }
}

/**
 * Main rendering function
 */
export async function renderAudio(composition, options = {}) {
  const renderer = new AudioRenderer(composition, options);
  
  try {
    const buffer = await renderer.render();
    const audioBuffer = renderer.bufferToAudioBuffer(buffer);
    const blob = await renderer.exportWAV(audioBuffer);
    
    return {
      blob,
      audioBuffer,
      duration: audioBuffer.duration,
      sampleRate: audioBuffer.sampleRate
    };
  } finally {
    renderer.dispose();
  }
}

export default AudioRenderer;
