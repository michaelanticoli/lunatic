# Quantumelodic Music Generation Engine - Architecture

## System Overview

This engine translates astrological natal chart data into unique musical compositions through a deterministic mapping system that preserves astrological significance while generating musically coherent output.

## Architecture Layers

### 1. Data Input Layer
- **Input**: JSON from Swiss Ephemeris processing
- **Structure**: Planetary positions, aspects, houses, speeds
- **Validation**: Ensures data completeness and accuracy

### 2. Astrological Analysis Layer
- **Planetary Mapping**: Modes, tonalities, instruments
- **Aspect Analysis**: Harmonic relationships, intervals
- **House Processing**: Rhythmic patterns, structural divisions
- **Speed Calculation**: Tempo modulation

### 3. Musical Translation Layer
- **Modal Assignment**: Planet → Mode mapping
- **Harmonic Generation**: Aspect → Interval/chord mapping
- **Rhythm Creation**: House → Rhythmic pattern mapping
- **Tempo Calculation**: Planetary speed → BPM conversion

### 4. Audio Synthesis Layer
- **Synthesis Engine**: Tone.js-based WebAudio synthesis
- **Instrument Library**: Synthesized instruments per planet
- **Effect Processing**: Reverb, delay, filtering
- **Mixing**: Balance, panning, dynamics

### 5. Export Layer
- **Format**: WAV, MP3 output
- **Metadata**: Embedded astrological data
- **Visualization**: Optional waveform/spectral display

## Technology Stack

### Core Components
- **Tone.js**: WebAudio framework for synthesis
- **Music Theory Library**: Custom astrological-musical mappings
- **Audio Export**: OfflineAudioContext for rendering
- **MIDI Support**: Optional MIDI export for external rendering

### Optional Enhancements (Post-MVP)
- **AI Layer**: Suno/MusicGen API for enhancement
- **Cloud Processing**: For heavy compositions
- **Caching**: Pre-generated elements

## Data Flow

```
Swiss Ephemeris JSON
    ↓
Data Validation & Parsing
    ↓
Astrological Analysis
    ↓
Musical Parameter Generation
    ↓
Composition Assembly
    ↓
Audio Synthesis (Tone.js)
    ↓
Audio File Export (WAV/MP3)
    ↓
Delivery to User
```

## MVP Implementation Strategy

### Week 1 Deliverables (Current Week)
1. ✅ Core data processing pipeline
2. ✅ Basic planetary → musical mapping
3. ✅ Simple synthesis engine
4. ✅ Audio export functionality
5. ✅ Integration with ephemeris data

### Post-MVP Enhancements
- AI enhancement layer (Suno/MusicGen)
- Advanced harmonic structures
- Extended instrument library
- User customization options
- Real-time preview

## Musical Mapping Framework

### Planetary Modes (Base Scale Assignment)
- **Sun**: Ionian (Major) - C Major
- **Moon**: Aeolian (Natural Minor) - A Minor
- **Mercury**: Dorian - D Dorian
- **Venus**: Lydian - F Lydian
- **Mars**: Phrygian - E Phrygian
- **Jupiter**: Mixolydian - G Mixolydian
- **Saturn**: Locrian - B Locrian
- **Uranus**: Whole Tone Scale
- **Neptune**: Diminished Scale
- **Pluto**: Chromatic/Altered Scale

### Aspect Harmonics (Interval Mapping)
- **Conjunction (0°)**: Unison/Octave
- **Sextile (60°)**: Major Third
- **Square (90°)**: Tritone
- **Trine (120°)**: Perfect Fifth
- **Opposition (180°)**: Minor Seventh

### House Rhythms (Structural Timing)
- Each house = measure/phrase length
- Angular houses (1,4,7,10) = Strong beats
- Succedent houses (2,5,8,11) = Medium emphasis
- Cadent houses (3,6,9,12) = Weak beats

### Tempo Calculation
```
Base BPM = 120
Adjusted BPM = 120 × (1 + (planetary_speed - average_speed) / average_speed)
Range: 60-180 BPM
```

## File Structure

```
quantumelodic-engine/
├── src/
│   ├── core/
│   │   ├── AstroParser.js          # Parse ephemeris JSON
│   │   ├── MusicalMapper.js        # Astrological → Musical mapping
│   │   ├── CompositionEngine.js    # Assemble musical structure
│   │   └── AudioRenderer.js        # Synthesize audio
│   ├── mappings/
│   │   ├── planetary-modes.js      # Planet → Mode definitions
│   │   ├── aspect-harmonics.js     # Aspect → Interval definitions
│   │   ├── house-rhythms.js        # House → Rhythm patterns
│   │   └── instruments.js          # Instrument definitions
│   ├── synthesis/
│   │   ├── Synthesizers.js         # Tone.js instrument builders
│   │   ├── Effects.js              # Audio effects
│   │   └── Mixer.js                # Audio mixing
│   └── utils/
│       ├── validation.js           # Data validation
│       ├── math.js                 # Musical mathematics
│       └── export.js               # File export utilities
├── tests/
│   └── sample-charts.js            # Test data
├── examples/
│   └── basic-usage.html            # Demo implementation
└── package.json
```

## API Design

### Primary Method
```javascript
const composition = await generateQuantumelodicComposition(natalChartJSON, options);
// Returns: { audioBlob, metadata, visualData }
```

### Configuration Options
```javascript
options = {
  duration: 180,              // seconds (default: 3 minutes)
  format: 'wav',              // 'wav' or 'mp3'
  quality: 'high',            // 'low', 'medium', 'high'
  includeMIDI: false,         // Optional MIDI export
  customMappings: null,       // Override default mappings
  visualize: true             // Generate visualization data
}
```

## Performance Considerations

- **Synthesis Time**: ~5-15 seconds for 3-minute composition
- **Memory Usage**: ~50-100MB during generation
- **File Size**: ~10-30MB WAV, ~3-8MB MP3
- **Browser Compatibility**: All modern browsers with WebAudio

## Security & Privacy

- All processing client-side (no data sent to external servers in MVP)
- Astrological data never leaves user's browser
- Optional cloud processing for heavy compositions (post-MVP)

## Future AI Enhancement Path

When ready to add AI layer:
1. Generate base composition with current engine
2. Send MIDI/musical parameters to AI service (Suno/MusicGen)
3. Use AI to enhance/orchestrate the composition
4. Maintain astrological mappings in enhanced version

This keeps the core logic intact while adding production value.

## Chart Generation Function

To generate astrological chart data from birth details:
```python
def generate_chart_data(birth_date, birth_time, timezone, lat, lon):
    birth_date_fmt = datetime.strptime(birth_date, "%Y-%m-%d").strftime("%Y/%m/%d")
    dt = Datetime(date=birth_date_fmt, time=birth_time, utcoffset=timezone)
    pos = GeoPos(lat, lon)
    ...
```
