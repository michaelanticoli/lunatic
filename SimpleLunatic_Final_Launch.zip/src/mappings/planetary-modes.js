/**
 * Planetary Mode Mappings
 * Defines the musical modes and tonal characteristics for each planet
 */

export const PLANETARY_MODES = {
  Sun: {
    mode: 'ionian',
    rootNote: 'C4',
    scale: ['C', 'D', 'E', 'F', 'G', 'A', 'B'],
    intervals: [0, 2, 4, 5, 7, 9, 11], // Semitones from root
    character: 'bright, major, confident',
    instrument: 'brass',
    waveform: 'triangle',
    brightness: 0.8
  },
  Moon: {
    mode: 'aeolian',
    rootNote: 'A3',
    scale: ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
    intervals: [0, 2, 3, 5, 7, 8, 10],
    character: 'emotional, introspective, minor',
    instrument: 'strings',
    waveform: 'sine',
    brightness: 0.4
  },
  Mercury: {
    mode: 'dorian',
    rootNote: 'D4',
    scale: ['D', 'E', 'F', 'G', 'A', 'B', 'C'],
    intervals: [0, 2, 3, 5, 7, 9, 10],
    character: 'communicative, quick, versatile',
    instrument: 'woodwind',
    waveform: 'square',
    brightness: 0.65
  },
  Venus: {
    mode: 'lydian',
    rootNote: 'F4',
    scale: ['F', 'G', 'A', 'B', 'C', 'D', 'E'],
    intervals: [0, 2, 4, 6, 7, 9, 11],
    character: 'beautiful, harmonious, raised fourth',
    instrument: 'harp',
    waveform: 'sine',
    brightness: 0.7
  },
  Mars: {
    mode: 'phrygian',
    rootNote: 'E4',
    scale: ['E', 'F', 'G', 'A', 'B', 'C', 'D'],
    intervals: [0, 1, 3, 5, 7, 8, 10],
    character: 'aggressive, Spanish, exotic',
    instrument: 'percussion',
    waveform: 'sawtooth',
    brightness: 0.9
  },
  Jupiter: {
    mode: 'mixolydian',
    rootNote: 'G4',
    scale: ['G', 'A', 'B', 'C', 'D', 'E', 'F'],
    intervals: [0, 2, 4, 5, 7, 9, 10],
    character: 'expansive, dominant, bluesy',
    instrument: 'organ',
    waveform: 'triangle',
    brightness: 0.75
  },
  Saturn: {
    mode: 'locrian',
    rootNote: 'B3',
    scale: ['B', 'C', 'D', 'E', 'F', 'G', 'A'],
    intervals: [0, 1, 3, 5, 6, 8, 10],
    character: 'dark, unstable, diminished',
    instrument: 'bass',
    waveform: 'sawtooth',
    brightness: 0.3
  },
  Uranus: {
    mode: 'whole-tone',
    rootNote: 'D5',
    scale: ['D', 'E', 'F#', 'G#', 'A#', 'C'],
    intervals: [0, 2, 4, 6, 8, 10],
    character: 'unstable, futuristic, dreamlike',
    instrument: 'synthesizer',
    waveform: 'custom',
    brightness: 0.85
  },
  Neptune: {
    mode: 'diminished',
    rootNote: 'F3',
    scale: ['F', 'G', 'Ab', 'Bb', 'B', 'C#', 'D', 'E'],
    intervals: [0, 2, 3, 5, 6, 8, 9, 11],
    character: 'mystical, dissolving, ethereal',
    instrument: 'pad',
    waveform: 'sine',
    brightness: 0.5
  },
  Pluto: {
    mode: 'chromatic',
    rootNote: 'C3',
    scale: ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
    intervals: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    character: 'transformative, intense, all-encompassing',
    instrument: 'distorted',
    waveform: 'sawtooth',
    brightness: 1.0
  }
};

/**
 * Get the musical mode for a given planet
 * @param {string} planetName - Name of the planet (e.g., 'Sun', 'Moon')
 * @returns {Object} Mode configuration object
 */
export function getPlanetaryMode(planetName) {
  return PLANETARY_MODES[planetName] || PLANETARY_MODES.Sun;
}

/**
 * Modify mode based on zodiac sign
 * @param {Object} modeConfig - Base mode configuration
 * @param {string} zodiacSign - Zodiac sign (e.g., 'Aries', 'Taurus')
 * @returns {Object} Modified mode configuration
 */
export function applyZodiacModification(modeConfig, zodiacSign) {
  const zodiacModifiers = {
    // Fire signs - raise overall pitch
    Aries: { pitchShift: 2, brightness: 0.1 },
    Leo: { pitchShift: 3, brightness: 0.15 },
    Sagittarius: { pitchShift: 4, brightness: 0.1 },
    
    // Earth signs - lower pitch, more stable
    Taurus: { pitchShift: -2, brightness: -0.1 },
    Virgo: { pitchShift: -1, brightness: -0.05 },
    Capricorn: { pitchShift: -3, brightness: -0.15 },
    
    // Air signs - add variation
    Gemini: { pitchShift: 1, brightness: 0.05 },
    Libra: { pitchShift: 0, brightness: 0.05 },
    Aquarius: { pitchShift: 2, brightness: 0.1 },
    
    // Water signs - soften
    Cancer: { pitchShift: -1, brightness: -0.1 },
    Scorpio: { pitchShift: -2, brightness: -0.15 },
    Pisces: { pitchShift: 0, brightness: -0.2 }
  };

  const modifier = zodiacModifiers[zodiacSign] || { pitchShift: 0, brightness: 0 };
  
  return {
    ...modeConfig,
    pitchShift: modifier.pitchShift,
    brightness: Math.max(0, Math.min(1, modeConfig.brightness + modifier.brightness))
  };
}

/**
 * Get frequency from note name
 * @param {string} note - Note name (e.g., 'C4', 'A3')
 * @returns {number} Frequency in Hz
 */
export function noteToFrequency(note) {
  const noteMap = {
    'C': -9, 'C#': -8, 'D': -7, 'D#': -6, 'E': -5, 'F': -4,
    'F#': -3, 'G': -2, 'G#': -1, 'A': 0, 'A#': 1, 'B': 2
  };
  
  const match = note.match(/^([A-G]#?)(\d+)$/);
  if (!match) return 440; // Default to A4
  
  const [, noteName, octave] = match;
  const noteOffset = noteMap[noteName];
  const octaveOffset = (parseInt(octave) - 4) * 12;
  const semitones = noteOffset + octaveOffset;
  
  return 440 * Math.pow(2, semitones / 12);
}

export default PLANETARY_MODES;
