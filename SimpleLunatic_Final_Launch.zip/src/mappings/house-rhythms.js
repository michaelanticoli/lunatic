/**
 * House Rhythms Mappings
 * Defines rhythmic patterns and structural timing for the 12 astrological houses
 */

export const HOUSE_RHYTHMS = {
  1: {
    name: 'First House (Ascendant)',
    quadrant: 'angular',
    element: 'fire',
    beatStrength: 1.0,
    rhythmPattern: [1, 0, 0, 0], // Strong downbeat
    timeSignature: '4/4',
    noteValue: 'quarter',
    accentPattern: 'strong',
    character: 'self, identity, initiation',
    structuralRole: 'opening',
    phraseLength: 8 // measures
  },
  2: {
    name: 'Second House',
    quadrant: 'succedent',
    element: 'earth',
    beatStrength: 0.6,
    rhythmPattern: [0, 1, 0, 1], // Syncopated
    timeSignature: '4/4',
    noteValue: 'eighth',
    accentPattern: 'medium',
    character: 'resources, values, security',
    structuralRole: 'development',
    phraseLength: 6
  },
  3: {
    name: 'Third House',
    quadrant: 'cadent',
    element: 'air',
    beatStrength: 0.4,
    rhythmPattern: [1, 1, 1, 1], // Quick, even
    timeSignature: '4/4',
    noteValue: 'sixteenth',
    accentPattern: 'light',
    character: 'communication, learning, siblings',
    structuralRole: 'transition',
    phraseLength: 4
  },
  4: {
    name: 'Fourth House (IC)',
    quadrant: 'angular',
    element: 'water',
    beatStrength: 0.9,
    rhythmPattern: [1, 0, 0, 0], // Deep foundation
    timeSignature: '3/4',
    noteValue: 'quarter',
    accentPattern: 'strong',
    character: 'home, roots, foundation',
    structuralRole: 'grounding',
    phraseLength: 8
  },
  5: {
    name: 'Fifth House',
    quadrant: 'succedent',
    element: 'fire',
    beatStrength: 0.7,
    rhythmPattern: [1, 0, 1, 0], // Playful
    timeSignature: '6/8',
    noteValue: 'eighth',
    accentPattern: 'medium-strong',
    character: 'creativity, pleasure, children',
    structuralRole: 'expression',
    phraseLength: 6
  },
  6: {
    name: 'Sixth House',
    quadrant: 'cadent',
    element: 'earth',
    beatStrength: 0.5,
    rhythmPattern: [1, 1, 0, 1], // Methodical
    timeSignature: '4/4',
    noteValue: 'eighth',
    accentPattern: 'medium',
    character: 'work, health, service',
    structuralRole: 'refinement',
    phraseLength: 5
  },
  7: {
    name: 'Seventh House (Descendant)',
    quadrant: 'angular',
    element: 'air',
    beatStrength: 1.0,
    rhythmPattern: [1, 0, 0, 0], // Partnership emphasis
    timeSignature: '4/4',
    noteValue: 'quarter',
    accentPattern: 'strong',
    character: 'relationships, partnerships, others',
    structuralRole: 'contrast',
    phraseLength: 8
  },
  8: {
    name: 'Eighth House',
    quadrant: 'succedent',
    element: 'water',
    beatStrength: 0.6,
    rhythmPattern: [0, 0, 1, 0], // Mysterious, hidden
    timeSignature: '5/4',
    noteValue: 'quarter',
    accentPattern: 'medium',
    character: 'transformation, shared resources, death',
    structuralRole: 'depth',
    phraseLength: 7
  },
  9: {
    name: 'Ninth House',
    quadrant: 'cadent',
    element: 'fire',
    beatStrength: 0.4,
    rhythmPattern: [1, 0, 1, 1], // Expansive
    timeSignature: '7/8',
    noteValue: 'eighth',
    accentPattern: 'light',
    character: 'philosophy, travel, higher learning',
    structuralRole: 'expansion',
    phraseLength: 6
  },
  10: {
    name: 'Tenth House (Midheaven)',
    quadrant: 'angular',
    element: 'earth',
    beatStrength: 1.0,
    rhythmPattern: [1, 0, 0, 0], // Achievement peak
    timeSignature: '4/4',
    noteValue: 'half',
    accentPattern: 'very-strong',
    character: 'career, public life, achievement',
    structuralRole: 'climax',
    phraseLength: 8
  },
  11: {
    name: 'Eleventh House',
    quadrant: 'succedent',
    element: 'air',
    beatStrength: 0.6,
    rhythmPattern: [1, 1, 0, 0], // Collective rhythm
    timeSignature: '4/4',
    noteValue: 'eighth',
    accentPattern: 'medium',
    character: 'friends, groups, aspirations',
    structuralRole: 'resolution',
    phraseLength: 6
  },
  12: {
    name: 'Twelfth House',
    quadrant: 'cadent',
    element: 'water',
    beatStrength: 0.3,
    rhythmPattern: [0, 1, 0, 0], // Dissolving, ethereal
    timeSignature: '3/4',
    noteValue: 'whole',
    accentPattern: 'very-light',
    character: 'unconscious, spirituality, endings',
    structuralRole: 'closure',
    phraseLength: 4
  }
};

/**
 * Convert note value string to duration in beats
 * @param {string} noteValue - Note value name (e.g., 'quarter', 'eighth')
 * @returns {number} Duration in beats
 */
export function noteValueToDuration(noteValue) {
  const durations = {
    'whole': 4.0,
    'half': 2.0,
    'quarter': 1.0,
    'eighth': 0.5,
    'sixteenth': 0.25,
    'thirty-second': 0.125
  };
  return durations[noteValue] || 1.0;
}

/**
 * Get house configuration by house number
 * @param {number} houseNumber - House number (1-12)
 * @returns {Object} House configuration
 */
export function getHouseConfig(houseNumber) {
  return HOUSE_RHYTHMS[houseNumber] || HOUSE_RHYTHMS[1];
}

/**
 * Generate rhythmic sequence for houses with planets
 * @param {Array} housePlacements - Array of {house: number, planet: string} objects
 * @returns {Array} Rhythmic sequence with timing
 */
export function generateHouseRhythmSequence(housePlacements) {
  const sequence = [];
  let currentTime = 0;
  
  // Sort by house number
  const sorted = housePlacements.sort((a, b) => a.house - b.house);
  
  for (const placement of sorted) {
    const houseConfig = getHouseConfig(placement.house);
    const pattern = houseConfig.rhythmPattern;
    const beatStrength = houseConfig.beatStrength;
    const duration = noteValueToDuration(houseConfig.noteValue);
    
    sequence.push({
      house: placement.house,
      planet: placement.planet,
      startTime: currentTime,
      pattern: pattern,
      beatStrength: beatStrength,
      duration: duration,
      phraseLength: houseConfig.phraseLength,
      timeSignature: houseConfig.timeSignature,
      structuralRole: houseConfig.structuralRole
    });
    
    currentTime += houseConfig.phraseLength * 4; // 4 beats per measure
  }
  
  return sequence;
}

/**
 * Calculate overall rhythmic complexity
 * @param {Array} housePlacements - Array of house placements
 * @returns {number} Complexity score (0-1)
 */
export function calculateRhythmicComplexity(housePlacements) {
  let complexity = 0;
  
  const angularCount = housePlacements.filter(p => 
    [1, 4, 7, 10].includes(p.house)
  ).length;
  
  const succedentCount = housePlacements.filter(p => 
    [2, 5, 8, 11].includes(p.house)
  ).length;
  
  const cadentCount = housePlacements.filter(p => 
    [3, 6, 9, 12].includes(p.house)
  ).length;
  
  // More cadent = more complex rhythms
  complexity = (cadentCount * 0.8 + succedentCount * 0.5 + angularCount * 0.2) / 
               housePlacements.length;
  
  return Math.max(0, Math.min(1, complexity));
}

/**
 * Generate measure pattern from house rhythm
 * @param {number} houseNumber - House number (1-12)
 * @param {number} measures - Number of measures to generate
 * @returns {Array} Array of beat objects with timing and strength
 */
export function generateMeasurePattern(houseNumber, measures = 4) {
  const houseConfig = getHouseConfig(houseNumber);
  const pattern = houseConfig.rhythmPattern;
  const beatStrength = houseConfig.beatStrength;
  const beats = [];
  
  for (let m = 0; m < measures; m++) {
    for (let b = 0; b < pattern.length; b++) {
      beats.push({
        measure: m + 1,
        beat: b + 1,
        active: pattern[b] === 1,
        strength: pattern[b] * beatStrength,
        time: m * pattern.length + b
      });
    }
  }
  
  return beats;
}

/**
 * Get structural section based on house quadrant
 * @param {number} houseNumber - House number (1-12)
 * @returns {string} Structural section name
 */
export function getStructuralSection(houseNumber) {
  const sections = {
    1: 'intro',
    2: 'verse_a',
    3: 'verse_b',
    4: 'pre_chorus',
    5: 'chorus',
    6: 'verse_c',
    7: 'bridge',
    8: 'breakdown',
    9: 'buildup',
    10: 'climax',
    11: 'outro_a',
    12: 'outro_b'
  };
  
  return sections[houseNumber] || 'section';
}

/**
 * Calculate tempo modulation based on house emphasis
 * @param {Array} housePlacements - Array of house placements
 * @param {number} baseTempo - Base tempo in BPM
 * @returns {number} Modified tempo in BPM
 */
export function calculateHouseTempo(housePlacements, baseTempo = 120) {
  let tempoModifier = 0;
  
  for (const placement of housePlacements) {
    const houseConfig = getHouseConfig(placement.house);
    
    // Fire houses increase tempo
    if (houseConfig.element === 'fire') {
      tempoModifier += 5;
    }
    // Water houses decrease tempo
    else if (houseConfig.element === 'water') {
      tempoModifier -= 3;
    }
    // Earth houses stabilize
    else if (houseConfig.element === 'earth') {
      tempoModifier += 0;
    }
    // Air houses slightly increase
    else if (houseConfig.element === 'air') {
      tempoModifier += 2;
    }
  }
  
  const avgModifier = housePlacements.length > 0 ? 
    tempoModifier / housePlacements.length : 0;
  
  return Math.max(60, Math.min(180, baseTempo + avgModifier));
}

export default HOUSE_RHYTHMS;
