export const PLANETARY_MODES = {
  MOON: 210.42, // Synodic Moon Frequency
};