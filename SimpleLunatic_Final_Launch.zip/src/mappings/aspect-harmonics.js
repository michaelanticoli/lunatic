/**
 * Aspect Harmonics Mappings
 * Defines the musical intervals and harmonic relationships for planetary aspects
 */

export const ASPECT_HARMONICS = {
  conjunction: {
    angle: 0,
    orb: 8,
    interval: 'unison',
    semitones: 0,
    ratio: '1:1',
    harmonic: 1,
    character: 'unity, blend, intensification',
    chordType: 'power',
    tension: 0.0
  },
  sextile: {
    angle: 60,
    orb: 6,
    interval: 'major-third',
    semitones: 4,
    ratio: '5:4',
    harmonic: 6,
    character: 'opportunity, ease, harmony',
    chordType: 'major',
    tension: 0.2
  },
  square: {
    angle: 90,
    orb: 8,
    interval: 'tritone',
    semitones: 6,
    ratio: '45:32',
    harmonic: 4,
    character: 'tension, challenge, dynamic',
    chordType: 'diminished',
    tension: 0.8
  },
  trine: {
    angle: 120,
    orb: 8,
    interval: 'perfect-fifth',
    semitones: 7,
    ratio: '3:2',
    harmonic: 3,
    character: 'flow, talent, ease',
    chordType: 'major-seventh',
    tension: 0.1
  },
  opposition: {
    angle: 180,
    orb: 8,
    interval: 'minor-seventh',
    semitones: 10,
    ratio: '16:9',
    harmonic: 2,
    character: 'polarity, awareness, balance',
    chordType: 'dominant-seventh',
    tension: 0.7
  },
  semisextile: {
    angle: 30,
    orb: 2,
    interval: 'minor-second',
    semitones: 1,
    ratio: '16:15',
    harmonic: 12,
    character: 'subtle, growth, adjustment',
    chordType: 'minor',
    tension: 0.5
  },
  semisquare: {
    angle: 45,
    orb: 2,
    interval: 'augmented-second',
    semitones: 3,
    ratio: '75:64',
    harmonic: 8,
    character: 'friction, minor stress',
    chordType: 'augmented',
    tension: 0.6
  },
  quintile: {
    angle: 72,
    orb: 2,
    interval: 'major-third-plus',
    semitones: 5,
    ratio: '5:4',
    harmonic: 5,
    character: 'creative, talent, gift',
    chordType: 'major-ninth',
    tension: 0.15
  },
  sesquiquadrate: {
    angle: 135,
    orb: 2,
    interval: 'minor-sixth',
    semitones: 8,
    ratio: '128:75',
    harmonic: 8,
    character: 'irritation, persistent tension',
    chordType: 'minor-seventh',
    tension: 0.65
  },
  biquintile: {
    angle: 144,
    orb: 2,
    interval: 'major-sixth',
    semitones: 9,
    ratio: '5:3',
    harmonic: 5,
    character: 'creative expression, mastery',
    chordType: 'major-sixth',
    tension: 0.2
  },
  quincunx: {
    angle: 150,
    orb: 2,
    interval: 'augmented-fifth',
    semitones: 8,
    ratio: '45:32',
    harmonic: 6,
    character: 'adjustment, strain, pivot',
    chordType: 'augmented',
    tension: 0.7
  }
};

/**
 * Calculate aspect between two planetary positions
 * @param {number} position1 - First planet position in degrees (0-360)
 * @param {number} position2 - Second planet position in degrees (0-360)
 * @returns {Object|null} Aspect configuration or null if no aspect
 */
export function calculateAspect(position1, position2) {
  let angle = Math.abs(position1 - position2);
  
  // Normalize to 0-180 range
  if (angle > 180) {
    angle = 360 - angle;
  }
  
  // Check each aspect type
  for (const [aspectName, aspectConfig] of Object.entries(ASPECT_HARMONICS)) {
    const difference = Math.abs(angle - aspectConfig.angle);
    
    if (difference <= aspectConfig.orb) {
      return {
        type: aspectName,
        exactAngle: angle,
        orb: difference,
        applying: position1 < position2,
        ...aspectConfig
      };
    }
  }
  
  return null;
}

/**
 * Get all aspects for a set of planetary positions
 * @param {Object} planets - Object with planet names as keys and positions as values
 * @returns {Array} Array of aspect objects
 */
export function getAllAspects(planets) {
  const aspects = [];
  const planetNames = Object.keys(planets);
  
  for (let i = 0; i < planetNames.length; i++) {
    for (let j = i + 1; j < planetNames.length; j++) {
      const planet1 = planetNames[i];
      const planet2 = planetNames[j];
      const aspect = calculateAspect(planets[planet1], planets[planet2]);
      
      if (aspect) {
        aspects.push({
          planet1,
          planet2,
          ...aspect
        });
      }
    }
  }
  
  return aspects.sort((a, b) => a.exactAngle - b.exactAngle);
}

/**
 * Generate chord notes from aspect
 * @param {string} rootNote - Root note (e.g., 'C4')
 * @param {Object} aspect - Aspect configuration
 * @returns {Array} Array of note names
 */
export function aspectToChord(rootNote, aspect) {
  const chordTemplates = {
    'power': [0, 7],
    'major': [0, 4, 7],
    'minor': [0, 3, 7],
    'diminished': [0, 3, 6],
    'augmented': [0, 4, 8],
    'major-seventh': [0, 4, 7, 11],
    'minor-seventh': [0, 3, 7, 10],
    'dominant-seventh': [0, 4, 7, 10],
    'major-sixth': [0, 4, 7, 9],
    'major-ninth': [0, 4, 7, 11, 14]
  };
  
  const template = chordTemplates[aspect.chordType] || [0, 4, 7];
  const notes = [];
  
  const rootMatch = rootNote.match(/^([A-G]#?)(\d+)$/);
  if (!rootMatch) return [rootNote];
  
  const [, noteName, octave] = rootMatch;
  const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const startIndex = noteNames.indexOf(noteName);
  
  for (const offset of template) {
    const noteIndex = (startIndex + offset) % 12;
    const octaveOffset = Math.floor((startIndex + offset) / 12);
    const newOctave = parseInt(octave) + octaveOffset;
    notes.push(`${noteNames[noteIndex]}${newOctave}`);
  }
  
  return notes;
}

/**
 * Calculate harmonic tension for a set of aspects
 * @param {Array} aspects - Array of aspect objects
 * @returns {number} Overall tension value (0-1)
 */
export function calculateHarmonicTension(aspects) {
  if (aspects.length === 0) return 0.5;
  
  const totalTension = aspects.reduce((sum, aspect) => sum + aspect.tension, 0);
  return totalTension / aspects.length;
}

/**
 * Generate harmonic series from fundamental frequency
 * @param {number} fundamental - Fundamental frequency in Hz
 * @param {number} harmonics - Number of harmonics to generate
 * @returns {Array} Array of harmonic frequencies
 */
export function generateHarmonicSeries(fundamental, harmonics = 8) {
  const series = [];
  for (let i = 1; i <= harmonics; i++) {
    series.push({
      harmonic: i,
      frequency: fundamental * i,
      amplitude: 1 / i // Natural decay
    });
  }
  return series;
}

export default ASPECT_HARMONICS;
