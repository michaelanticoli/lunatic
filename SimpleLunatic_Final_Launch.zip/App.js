import React, { useState } from 'react';
import { StyleSheet, View, SafeAreaView } from 'react-native';
import { playPulse } from './src/logic/PulseEngine';
import { calculateEchoes } from './src/logic/LunarSync';

export default function App() {
  const [seeds, setSeeds] = useState([]);

  const handlePlantSeed = (text) => {
    playPulse('moon');
    const now = new Date();
    const newSeed = { text, timestamp: now, echoes: calculateEchoes(now) };
    setSeeds([newSeed, ...seeds]);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Ledger UI Component would go here */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' }
});
